#!/bin/dash

# --- Lenic help function - Version [cat usr/lib/lenic/VERSION] ---

echo "lenic 0.2-2"
echo "Usage: 'lenic [options]'"; echo ""
echo "Following options are available:"
echo " -> 'help' - lists all available commands"
echo " -> 'install' - runs a tool, which can installs bunch of packages"
echo " -> 'update' - updates your system"
echo " -> 'upgrade' - runs a tool which can upgrade your system to another debian release -- STILL IN ALPHA PHASE"
echo " -> 'debtemplate' - tool making templates for building deb packages"
echo " -> 'about' - gives you information about the program"
