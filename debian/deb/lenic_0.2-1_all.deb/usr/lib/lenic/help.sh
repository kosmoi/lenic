#!/bin/dash

# --- Lenic 0.2-1 help function ---

echo "lenic 0.2.1"
echo "Usage: 'lenic [command]'"; echo ""
echo "Following commands are available:"
echo " 'help' - lists all available commands"
echo " 'install' - runs a tool, which can installs bunch of packages"
echo " 'update' - updates your system"
echo " 'upgrade' - runs a tool which can upgrade your system to another debian release -- STILL IN ALPHA PHASE"
echo " 'debtemplate' - tool making templates for building deb packages"
echo " 'about' - gives you information about the program"
