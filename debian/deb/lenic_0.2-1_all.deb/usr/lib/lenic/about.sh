#!/bin/dash

# --- Lenic 0.2-1 about function ---

echo "   __            _"
echo "  / /  ___ ___  (_)___"
echo " / /__/ -_) _ \/ / __/"
echo "/____/\__/_//_/_/\__/"
echo ""
echo "Lenic version 0.2-1 - DEB-Package"
echo "Creator: kosmoi.github.io"
echo "Website: kosmoi.github.io/lenic"
echo "License: kosmoi.github.io/license.htm"
echo "Description: Lenic (which stands for 'little executable nonsence interactive console') is a tool, which was made for handling debian system more easily."
echo ""
echo "released on 2022-11-28"
